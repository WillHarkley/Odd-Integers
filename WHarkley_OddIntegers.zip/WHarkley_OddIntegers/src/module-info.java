module WHarkley_OddIntegers {
}