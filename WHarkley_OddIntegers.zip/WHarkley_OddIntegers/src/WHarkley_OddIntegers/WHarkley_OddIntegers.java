//Assignment 3 Product of Odd Integers - Purpose: To calculate the odd number from 1-15
// CSIS212 D02
// Last updated: April 4, 2022 

package WHarkley_OddIntegers;

public class WHarkley_OddIntegers {

	public static void main(String[] args) {
		//Exercise 4.12: Write an application that calculates the product of the odd integers from 1 to 15.
		
		System.out.println("William Harkley Assignment 3");
		
		//declare variables
		int product = 1; 
		
		//total of numbers 1- 15 multiplied by every odd number
		for (int numbers = 1; numbers <= 15; numbers += 2)
		{
			if (numbers % 2 != 0)
			
				product *= numbers;
			
		}
		
		System.out.printf("\n Product of odd number is %d", product);
	}

}
